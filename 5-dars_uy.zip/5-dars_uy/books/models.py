from django.db import models

#Create your models here.

class Author(models.MOdel):
    name = models.CharField(max_lenght=100)
    surname = models.CharField(max_lenght=100)
    year=models.CharField(ma_lenght=100)
    
    class Meta:
        db_table = 'author'
    
    def __str__(self):
        return self.name
    
class Review(models.Model):
    comment = models.CharField(max_lenghth=256)
    star_given = models.IntegerField()
    user = models.ImageField()